//
//  addPageViewController.h
//  Best Before
//
//  Created by QUAQUA on 2017/12/29.
//  Copyright © 2017年 Patatas. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface addPageViewController : UIViewController

@end

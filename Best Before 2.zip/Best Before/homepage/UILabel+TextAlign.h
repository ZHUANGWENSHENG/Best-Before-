//
//  UILabel+TextAlign.h
//  Best Before
//
//  Created by Patatas on 2017/12/25.
//  Copyright © 2017年 Patatas. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (TextAlign)

@property (nonatomic, assign) BOOL isTop;
@property (nonatomic, assign) BOOL isBottom;

@end

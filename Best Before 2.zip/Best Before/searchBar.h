//
//  searchBar.h
//  Best Before
//
//  Created by Patatas on 2018/1/6.
//  Copyright © 2018年 Patatas. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface searchBar : UINavigationController

@end
